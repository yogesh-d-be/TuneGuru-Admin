import logo from "../assests/tuneguru_logo.png"
import profile from "../assests/profile.jpg"
import add from '../assests/plus.png'
import list from '../assests/list.png'
import order from '../assests/order.png'
import upload from '../assests/upload.png'
import remove from '../assests/deleted.png'
import gif from '../assests/Hammer gif.gif'
import tuneguru from '../assests/Tuneguru.png'
import book from '../assests/ordered.png'
import contact from '../assests/customer-service.png'
import mender from '../assests/mender.png'

export const assests = {
    logo,
    profile,
    add,
    list,
    order,
    upload,
    remove,
    gif,
    tuneguru,
    book,
    contact,
    mender
};
