// import axios from "axios";
// import React, { useEffect, useState } from "react";
// import { toast } from "react-toastify";

// function Contact({API}){

//     const [contact, setContact] = useState();

//     const fetchAllContacted = async() =>{
        

//         try {
//             const response = await axios.get(`${API}/api/contact/listform`)
//             if (response.status === 200){
//                 setContact(response.data.data)
//             }
//             else{
//                 toast.error("Error during fetching contacted message")
//             }
//         } catch (error) {
//             toast.error("Error during fetching contacted message")
//         }
//     }

//     useEffect(()=>{
//         fetchAllContacted();
//         console.log(contact);
//     },[])
//     const renderFile = (fileUrl) => {
//         const fileExtension = fileUrl.split('.').pop().toLowerCase();
//         if (['jpg', 'jpeg', 'png'].includes(fileExtension)) {
//             return <img src={fileUrl} alt="Contacted File" className="w-20 h-20" />;
//         } else if (['doc', 'docx', 'pdf'].includes(fileExtension)) {
//             return (
//                 <a href={fileUrl} target="_blank" rel="noopener noreferrer" className="text-blue-500 underline">
//                     {fileUrl.split('/').pop()}
//                 </a>
//             );
//         } else {
//             return null;
//         }
//     };

//     return(
//         <>
//         {contact.map((message,index)=>(
//             <div key={index} className="flex py-6 px-10 w-[80%] justify-center items-center bg-orange-300 rounded-xl ml-[10%] mt-12">
//                 <div className="flex flex-col w-[40%]">
//                 <p>{message.name}</p>
//                 <p>{message.mobileNumber}</p>
//                 <p>{message.emailId}</p>
//                 </div>
//                 <div className="flex flex-col w-[40%]">
//                     <p>{message.message}</p>
//                     {message.contactFile && (
//                                 <div className="m-2">
//                                     {renderFile(message.contactFile)}
//                                 </div>
//                             )}
//                 </div>
//                 </div>
//         ))}
//         </>
//     )
// }

// export default Contact;

import axios from "axios";
import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { toast } from "react-toastify";
import FileViewer from 'react-file-viewer';
function Contact({ API }) {
    const [contact, setContact] = useState([]);

    const fetchAllContacted = async () => {
        try {
            const response = await axios.get(`${API}/api/contact/listform`);
            if (response.status === 200) {
                setContact(response.data.data);
            } else {
                toast.error("Error during fetching contacted message");
            }
        } catch (error) {
            toast.error("Error during fetching contacted message");
        }
    };

    useEffect(() => {
        fetchAllContacted();
        console.log(contact);
    }, []);

    const renderFile = (fileUrl) => {

        const filetype = fileUrl.split('.').pop().toLowerCase();
        const fullFilePath = `${API}/documents/contactform/${fileUrl}`;
        return (
            <div className="file-preview">
                <FileViewer
                    fileType={filetype}
                    filePath={fullFilePath}
                    errorComponent={() => <p>File type not supported for preview</p>}
                    onError={(e) => console.error(e)}
                />
            </div>
        )
        // const fileExtension = fileUrl.split('.').pop().toLowerCase();
        // if (['jpg', 'jpeg', 'png'].includes(fileExtension)) {
        //     return <img src={`${API}/images/contactform/${fileUrl}`} alt="Contacted File" className="w-20 h-20" />;
        // } else if (fileExtension === 'pdf') {
        //     return (
        //         <iframe 
        //             src={`${API}/images/contactform/${fileUrl}`} 
        //             title="PDF Preview" 
        //             className="w-full h-48" 
        //             style={{ border: 'none' }} 
        //         />
        //     );
        // } else if (['doc', 'docx'].includes(fileExtension)) {
        //     return (
        //         <iframe 
        //             src={`https://view.officeapps.live.com/op/embed.aspx?src=${API}/images/contactform/${fileUrl}`} 
        //             title="DOC Preview" 
        //             className="w-full h-48" 
        //             style={{ border: 'none' }} 
        //         />
        //     );
        // } else {
        //     return <p>File type not supported for preview</p>;
        // }
    };

    return (
        <>
            {contact.map((message, index) => (
                <div key={index} className="flex py-6 px-10 w-[80%] justify-center items-center bg-orange-300 rounded-xl ml-[10%] mt-12 ">
                    <div className="flex flex-col w-[40%]justify-center">
                        <p className="font-semibold">Name: {message.name}</p>
                        <p className="font-semibold">Mobile Number: {message.mobileNumber}</p>
                        <p className="font-semibold">Email: {message.emailId}</p>
                    </div>
                    <div className="flex flex-col w-[40%] justify-center items-center">
                        <p className="font-semibold">Message: <span className="font-bold">{message.message}</span></p>
                        <div className="flex flex-wrap">
                            {message.contactFile && (
                                <div className="m-2">
                                    {renderFile(message.contactFile)}
                                </div>
                            )}
                        </div>
                    </div>
                </div>
            ))}
        </>
    );
}

export default Contact;
