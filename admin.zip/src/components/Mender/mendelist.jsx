import React from "react";

function MenderList(){
    return(
        <>
        </>
    )
}

export default MenderList;